package cs355.controller;

import java.awt.event.MouseEvent;

public class Controller3DState implements IControllerState {
	
	public Controller3DState() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public stateType getType() {
		return stateType.THREED;
	}

}
